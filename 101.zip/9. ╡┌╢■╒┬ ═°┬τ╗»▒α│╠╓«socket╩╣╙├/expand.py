import socket

hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)
addr = socket.gethostbyname("www.baidu.com")
host = socket.gethostbyaddr(ip)
sername = socket.getservbyport(3389, "tcp")
port = socket.getservbyname('http')

print("gethostname：",hostname)
print("gethostbyname：",ip)
print("gethostbyname：",addr)
print("gethostbyaddr：",host)
print("getservbyport：",sername)
print("getservbyname：",port)
