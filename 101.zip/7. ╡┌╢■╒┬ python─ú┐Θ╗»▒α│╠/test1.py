
def start():
    print("hello world!")

if __name__ == '__main__':
    try:
        start()
    except KeyboardInterrupt:
        print("interrupted by user, killing all threads...")