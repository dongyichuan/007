b = "ms08067 "
a = "全局变量 "

def start():
    a = "局部变量 "
    print("start 函数输出部分： ",b,a)

if __name__ == '__main__':
    try:
        start()
        print("main函数输出部分：",b,a)
    except KeyboardInterrupt:
        print("interrupted by user, killing all threads...")
