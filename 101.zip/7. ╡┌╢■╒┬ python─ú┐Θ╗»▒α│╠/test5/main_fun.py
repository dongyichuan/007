from sound import hello

hello.hello()
