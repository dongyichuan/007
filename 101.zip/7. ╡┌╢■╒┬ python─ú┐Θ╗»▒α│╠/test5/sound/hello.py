def hello():
    print("sound/hello.py/hello()")

def syman():
    print("sound/hello.py/syman()")