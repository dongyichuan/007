
if __name__ == '__main__':
    print("This program is run directly!")
elif __name__=='hello':
    print("This program is used as a module.")