import optparse

def banner():
    print('\033[1;34m########################################################################################\033[0m\n'
          '\033[1;34m######################################\033[1;32m贝塔安全实验室\033[1;34m#####################################\033[0m\n'
          '\033[1;34m########################################################################################\033[0m\n')

def start():
    banner()
    usage = "python %prog -u/--user <target user> -p/--password <target password>"
    parser = optparse.OptionParser(usage)
    parser.add_option('-u', '--user', dest='User', type='string', help='target user', default='root')
    parser.add_option('-p', '--password', dest='Pwd', type='string', help='target password')
    options, args = parser.parse_args()

    print("用户名为", options.User)
    print("密码为", options.Pwd)

if __name__ == '__main__':
    try:
        start()
    except KeyboardInterrupt:
        print("interrupted by user, killing all threads...")
