import argparse

def banner():
    print('\033[1;34m########################################################################################\033[0m\n'
          '\033[1;34m######################################\033[1;32m贝塔安全实验室\033[1;34m#####################################\033[0m\n'
          '\033[1;34m########################################################################################\033[0m\n')

def start():
    banner()
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--user', dest='User', type=str, default='root', help='target User')
    parser.add_argument('-s', '--sex', dest='Sex', type=str, choices=['男', '女'], default='男', help='target Sex')
    parser.add_argument('-n', '--number', dest='Num', nargs=2, required=True, type=int, help='target Two Numbers')
    print(parser.parse_args().User,parser.parse_args().Sex,parser.parse_args().Num)

if __name__ == '__main__':
    try:
        start()
    except KeyboardInterrupt:
        print("interrupted by user, killing all threads...")