import sys, getopt

def banner():
    print('\033[1;34m########################################################################################\033[0m\n'
          '\033[1;34m######################################\033[1;32m贝塔安全实验室\033[1;34m#####################################\033[0m\n'
          '\033[1;34m########################################################################################\033[0m\n')

def usage():
    print('-h: --help 帮助;')
    print('-u: --url  域名;')
    print('eg: python -u "www.baidu.com" ')

def start(argv):
    url = ""
    file = ""
    if len(argv) < 1:
        print("-h 帮助信息;\n")
        sys.exit()
    try:
        banner()
        opts, args = getopt.getopt(argv, "-u:-h",["help","file="])
    except getopt.GetoptError:
        print('Error an argument!')
        sys.exit()
    for opt, arg in opts:
        if opt == "-u":
            url = arg
        elif opt == "--file":
            file = arg
        elif (opt == "-h") or (opt == "--help"):
            usage()
    if (len(url)>0) or (len(file)>0):
        print(url,file)

if __name__ == '__main__':
    try:
        start(sys.argv[1:])
    except KeyboardInterrupt:
        print("interrupted by user, killing all threads...")