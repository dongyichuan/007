import sys

def start(argv):
    print('程序名：',argv[0])
    print('第一个参数：',argv[1])
    print('第二个参数：',argv[2])
    print('第三个参数：',argv[3])

if __name__ == '__main__':
    try:
        start(sys.argv[0:])
    except KeyboardInterrupt:
        print("interrupted by user, killing all threads...")